# Nepal Journalist Federation Salyan Website

Responsive Nepali static website with Home, About, Executive Committee, News & Updates, Programs & Events, Photo Gallery, and Contact sections.

## Publish with GitHub Pages
1. Create a public repository on https://github.com/new.
2. Upload `index.html`, `style.css`, `script.js`, and `README.md` to the repository root.
3. Open Settings → Pages.
4. Select **Deploy from a branch**, branch **main**, folder **/(root)**, then Save.
5. GitHub will display the published site URL in the Pages settings.

## Customize before publishing
Replace placeholder committee names, contact details, sample news and event copy, and sample gallery photos with verified official information. Edit `index.html` and `style.css`.

This is a static website starter; it has no database or admin panel. Updates are made by editing and re-uploading files to GitHub.
